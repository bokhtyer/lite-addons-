/**
 * Plugin Name: LiteAddons Elementor
 * Description: Create unlimited widgets with Elementor Page Builder.
 * Version:     1.0.0
 * Author:      Bokhtyer Abid
 * Author URI:  http://abiddev.com
 * Plugin URI:  http://abiddev.com/lite-addons-elementor/
 * Tags: elementor, elements, addons, elementor addons, elementor widget, page builder, builder,  wordpress * page builder
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */


== Description ==


Take your Elementor page building experience to the next level with liteaddons Elements for Elementor. This is the last widget pack you will need. Find everything in one place and get more than 2+ free widgets for your Elementor website. All our elements are easy to use and built with our unique Widget Creator framework. 
<br>
Use any of are free widgets or upgrade to our pro version and enjoymore unique widgets for Elementor. Each element comes with a bunch of options to control every possible setting. In case you are missing something you can easily add it using our unique Widget Creator Framework.

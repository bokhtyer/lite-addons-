<?php
namespace LiteAddonsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * LiteAddons Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class LiteAddonsButton extends \Elementor\Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve LiteAddons Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lite_button';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve LiteAddons Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Button', 'lite-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve LiteAddons  widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the LiteAddons Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'lite-addons' ];
	}

	public function get_keywords() {
		return [ 'button','lite-button','animation-btn','lite-addons-button' ];
	}

	public function get_script_depends() {
		return [ 'lite-addons'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'lite-addons'),
	        'top-left'      => esc_html__('Top Left', 'lite-addons') ,
	        'top-center'    => esc_html__('Top Center', 'lite-addons') ,
	        'top-right'     => esc_html__('Top Right', 'lite-addons') ,
	        'center'        => esc_html__('Center', 'lite-addons') ,
	        'center-left'   => esc_html__('Center Left', 'lite-addons') ,
	        'center-right'  => esc_html__('Center Right', 'lite-addons') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'lite-addons') ,
	        'bottom-center' => esc_html__('Bottom Center', 'lite-addons') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'lite-addons') ,
	    ];

	    return $position_options;
	}
	protected function _register_controls() {
		$this->start_controls_section(
			'Button',
			array(
				'label'		=> __('Button','lite-addons')
			)
		);
		$this->add_control(
			'button_text',
			array(
				'label' 	=> esc_html__('Button Text','lite-addons'),
				'type'		=> Controls_Manager::TEXT,
				'default'	=> 'Read More'
			)
		);
		$this->add_control(
			'button_link',
			array(
				'label' 	=> esc_html__('Button Link','lite-addons'),
				'type'		=> Controls_Manager::TEXT,
				'default'	=> '#'
			)
		);
		$this->end_controls_section();

		// Start Controls Style Sections
		// Button Style
		$this->start_controls_section(
			'button_style',
			array(
				'label'		=> __('Button Style','lite-addons'),
				'tab'		=> Controls_Manager::TAB_STYLE,
			)
		);
	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		extract($settings);
		$button_text = $settings['button_text'];
		$button_link = $settings['button_link'];
        ?>
        <div class="lite-button">
        	<a class="lite-button-default" href="#">Read More</a>
        </div>
        <?php
	}

}
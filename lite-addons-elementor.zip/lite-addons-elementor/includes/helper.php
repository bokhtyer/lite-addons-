<?php 
namespace LiteAddonsElementor\Helper;

// BDT Position
function element_pack_position() {
    $position_options = [
        ''              => esc_html__('Default', 'lite-addons'),
        'top-left'      => esc_html__('Top Left', 'lite-addons') ,
        'top-center'    => esc_html__('Top Center', 'lite-addons') ,
        'top-right'     => esc_html__('Top Right', 'lite-addons') ,
        'center'        => esc_html__('Center', 'lite-addons') ,
        'center-left'   => esc_html__('Center Left', 'lite-addons') ,
        'center-right'  => esc_html__('Center Right', 'lite-addons') ,
        'bottom-left'   => esc_html__('Bottom Left', 'lite-addons') ,
        'bottom-center' => esc_html__('Bottom Center', 'lite-addons') ,
        'bottom-right'  => esc_html__('Bottom Right', 'lite-addons') ,
    ];

    return $position_options;
}